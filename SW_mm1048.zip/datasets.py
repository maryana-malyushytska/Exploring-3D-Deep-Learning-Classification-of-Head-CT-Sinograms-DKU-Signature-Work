import os
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset
from scipy.ndimage import zoom
import pydicom

def parse_label(label_str):
    """Parse one-hot string from labels.csv into 0 (normal) or 1 (abnormal)."""
    vals = [int(v) for v in str(label_str).replace('"','').split(",")]
    if vals == [0,1]:
        return 0  # normal
    elif vals == [1,0]:
        return 1  # abnormal
    else:
        raise ValueError(f"Unexpected label format: {vals}")

class Volume3DDataset(Dataset):
    def __init__(self, csv_file, root_dir, target_shape=(192,192,60),
                 batches=("batch_1","batch_2","batch_3","batch_4","batch_5","batch_6","batch_7"),
                 cache_dir="ct_cache"):
        """
        Args:
            csv_file (str): CSV file with columns [patient_id, label]
            root_dir (str): base folder (e.g., ct_scans/head_ct_dataset_anon)
            target_shape (tuple): desired (H, W, D)
            batches (tuple): which batch folders to use
            cache_dir (str): folder to store cached .npy volumes
        """
        self.df = pd.read_csv(csv_file).reset_index(drop=True)
        self.root_dir = root_dir
        self.target_shape = target_shape
        self.batches = batches
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)

        # store parsed labels
        self.labels = [parse_label(row.label) for _, row in self.df.iterrows()]

        # filter to only patients that actually exist in the specified batches
        self.df = self.df[self.df["patient_id"].apply(self._check_complete_case)].reset_index(drop=True)

    def _check_complete_case(self, patient_id):
        """Return True if patient has reconstructed_image folder with DICOMs."""
        for batch in self.batches:
            img_folder = os.path.join(self.root_dir, batch, patient_id, "reconstructed_image")
            if os.path.isdir(img_folder) and any(f.endswith(".dcm") for f in os.listdir(img_folder)):
                return True
        return False

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        label = parse_label(row.label)
        pid = row.patient_id

        # --- Cached file path ---
        cache_path = os.path.join(self.cache_dir, f"{pid}_{self.target_shape[0]}x{self.target_shape[2]}.npy")

        if os.path.exists(cache_path):
            try:
                volume = np.load(cache_path)
                if volume.shape[1:] == self.target_shape:
                    return torch.tensor(volume, dtype=torch.float32), torch.tensor(label, dtype=torch.long)
            except Exception:
                pass  # if corrupted, reload and overwrite

        # --- Locate volume folder ---
        case_folder = None
        for batch in self.batches:
            candidate = os.path.join(self.root_dir, batch, pid, "reconstructed_image")
            if os.path.isdir(candidate):
                case_folder = candidate
                break
        if case_folder is None:
            raise FileNotFoundError(f"{pid} not found in {self.batches}")

        # --- Load DICOM slices ---
        dcm_files = sorted(
            [f for f in os.listdir(case_folder) if f.endswith(".dcm")],
            key=lambda x: int(''.join(filter(str.isdigit, x)) or 0)
        )
        if len(dcm_files) == 0:
            raise FileNotFoundError(f"No DICOMs found in {case_folder}")

        slices = [pydicom.dcmread(os.path.join(case_folder, f)) for f in dcm_files]
        volume = np.stack([s.pixel_array for s in slices], axis=-1).astype(np.float32)

        # --- Normalize intensity ---
        volume = (volume - np.min(volume)) / (np.max(volume) - np.min(volume) + 1e-8)

        # --- Isotropic voxel resampling ---
        try:
            px, py = slices[0].PixelSpacing
            pz = float(slices[0].SliceThickness)
            spacing = np.array([px, py, pz], dtype=np.float32)
            spacing /= spacing.min()
        except Exception:
            spacing = np.array([1.0, 1.0, 1.0], dtype=np.float32)

        zoom_factors = (
            self.target_shape[0] / volume.shape[0] / spacing[0],
            self.target_shape[1] / volume.shape[1] / spacing[1],
            self.target_shape[2] / volume.shape[2] / spacing[2],
        )
        volume = zoom(volume, zoom_factors, order=1)

        # --- Depth correction (pad or crop to match target_shape) ---
        current_d = volume.shape[-1]
        target_d = self.target_shape[2]

        if current_d < target_d:
            pad = (target_d - current_d) // 2
            volume = np.pad(volume, ((0,0), (0,0), (pad, target_d - current_d - pad)), mode='constant')
        elif current_d > target_d:
            start = (current_d - target_d) // 2
            volume = volume[..., start:start+target_d]

        # --- Add channel dimension ---
        volume = np.expand_dims(volume, axis=0)

        return torch.tensor(volume, dtype=torch.float32), torch.tensor(label, dtype=torch.long)

class Sinogram3DDataset(Dataset):
    def __init__(self, csv_file, root_dir, target_shape=(192,192,96), 
                 batches=("batch_1", "batch_2", "batch_3", "batch_4", "batch_5", "batch_6", "batch_7")):
        """
        Args:
            csv_file (str): path to CSV with patient_id and label
            root_dir (str): base folder (ct_scans/head_ct_dataset_anon)
            target_shape (tuple): desired (H, W, N_proj)
            batches (tuple): which batch folders to use (default: batch_1–3)
        """
        self.df = pd.read_csv(csv_file).reset_index(drop=True)
        self.root_dir = root_dir
        self.target_shape = target_shape
        self.batches = batches

        # store parsed labels
        self.labels = [parse_label(row.label) for _, row in self.df.iterrows()]

        # filter to only patients that actually exist in the specified batches
        self.df = self.df[self.df["patient_id"].apply(self._check_complete_case)].reset_index(drop=True)

    def _check_complete_case(self, patient_id):
        """Return True if patient has sinogram + recon image in allowed batches."""
        for batch in self.batches:
            case_folder = os.path.join(self.root_dir, batch, patient_id)
            sino_path   = os.path.join(case_folder, "sinogram", "sinogram.npy")
            img_folder  = os.path.join(case_folder, "reconstructed_image")
            if os.path.exists(sino_path) and os.path.isdir(img_folder):
                return True
        return False

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        case_folder = None
        for batch in self.batches:
            candidate = os.path.join(self.root_dir, batch, row.patient_id)
            if os.path.exists(os.path.join(candidate, "sinogram", "sinogram.npy")):
                case_folder = candidate
                break
        if case_folder is None:
            raise FileNotFoundError(f"{row.patient_id} not found in {self.batches}")

        sino_path = os.path.join(case_folder, "sinogram", "sinogram.npy")
        label = parse_label(row.label)
        sinogram = np.load(sino_path)

        # normalize
        sinogram = (sinogram - sinogram.min()) / (sinogram.max() - sinogram.min() + 1e-8)

        # resample to uniform shape
        zoom_factors = (
            self.target_shape[0] / sinogram.shape[0],
            self.target_shape[1] / sinogram.shape[1],
            self.target_shape[2] / sinogram.shape[2],
        )
        sinogram = zoom(sinogram, zoom_factors, order=1)

        # add channel dim (C, H, W, D)
        sinogram = np.expand_dims(sinogram, axis=0)

        return torch.tensor(sinogram, dtype=torch.float32), torch.tensor(label, dtype=torch.long)